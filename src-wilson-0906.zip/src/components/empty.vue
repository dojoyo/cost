<template>
  <div>
    <!--模块名称-->
  </div>
</template>
<script>
  export default {
    name: '',
    components: {},
    props: {
    },
    data() {
      return {
      }
    },
    methods: {

    }
  }
</script>

<style lang="scss" scoped>
</style>
